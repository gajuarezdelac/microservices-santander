package mx.santander.pcau.cecos.mxfemscecosservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MxfeMsCecosServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MxfeMsCecosServiceApplication.class, args);
	}

}
