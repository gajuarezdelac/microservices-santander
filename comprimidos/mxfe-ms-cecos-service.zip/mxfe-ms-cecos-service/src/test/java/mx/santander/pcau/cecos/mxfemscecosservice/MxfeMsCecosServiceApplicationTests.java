package mx.santander.pcau.cecos.mxfemscecosservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxfeMsCecosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
