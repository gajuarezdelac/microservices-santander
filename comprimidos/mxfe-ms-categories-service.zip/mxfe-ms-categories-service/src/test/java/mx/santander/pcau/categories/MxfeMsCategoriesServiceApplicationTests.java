package mx.santander.pcau.categories;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxfeMsCategoriesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
