package mx.santander.pcau.solvinggroups.mxfemssolvinggroupsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxfeMsSolvingGroupsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
