package mx.santander.pcau.solvinggroups.mxfemssolvinggroupsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MxfeMsSolvingGroupsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MxfeMsSolvingGroupsServiceApplication.class, args);
	}

}
