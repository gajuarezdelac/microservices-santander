package mx.santander.pcau.regions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MxfeMsRegionsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MxfeMsRegionsServiceApplication.class, args);
	}

}
