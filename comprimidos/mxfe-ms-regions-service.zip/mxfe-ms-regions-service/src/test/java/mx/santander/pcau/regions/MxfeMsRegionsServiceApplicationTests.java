package mx.santander.pcau.regions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxfeMsRegionsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
