package mx.santander.pcau.subjects.mxfemssubjectsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxfeMsSubjectsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
