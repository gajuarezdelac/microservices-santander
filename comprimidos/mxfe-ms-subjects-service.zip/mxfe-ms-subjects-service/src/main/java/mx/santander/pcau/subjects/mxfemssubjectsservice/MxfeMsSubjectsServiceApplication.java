package mx.santander.pcau.subjects.mxfemssubjectsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MxfeMsSubjectsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MxfeMsSubjectsServiceApplication.class, args);
	}

}
