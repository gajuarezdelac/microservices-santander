package mx.santander.pcau.forms.mxfemsformsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxfeMsFormsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
