package mx.santander.pcau.forms.mxfemsformsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MxfeMsFormsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MxfeMsFormsServiceApplication.class, args);
	}

}
