package mx.santander.pcau.resolvers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxfeMsResolversServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
