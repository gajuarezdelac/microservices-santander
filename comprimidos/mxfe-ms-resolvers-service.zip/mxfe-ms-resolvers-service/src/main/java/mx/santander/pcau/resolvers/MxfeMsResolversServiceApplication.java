package mx.santander.pcau.resolvers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MxfeMsResolversServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MxfeMsResolversServiceApplication.class, args);
	}

}
