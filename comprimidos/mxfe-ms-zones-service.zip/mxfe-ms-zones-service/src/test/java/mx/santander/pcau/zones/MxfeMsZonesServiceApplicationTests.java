package mx.santander.pcau.zones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxfeMsZonesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
